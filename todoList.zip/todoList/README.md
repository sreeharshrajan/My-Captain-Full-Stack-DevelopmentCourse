# To Do List using Javascript DOM

You can do CRUD operations
